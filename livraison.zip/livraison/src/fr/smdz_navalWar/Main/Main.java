package fr.smdz_navalWar.Main;

import java.util.Scanner;

/**
 * <b>Main est la classe principale du projet.</b>
 * <p>
 * Elle permet une première intéraction avec l'utilisateur en vue de choisir le <span>Mode</span> à utiliser pour jouer.<br>
 * Les modes disponibles sont: 
 * <ul>
 * <li>Mode console</li>
 * <li>Mode graphique</li>
 * </ul>
 * 
 * En fonction du choix de l'utilisateur, elle exécute un programme différent.<br>
 * Soit l'utilisateur joue dans la console soit il joue sur l'interface graphique. 
 * </p>
 * 
 * @see Main_Model
 * @see Main_View
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Main {

	/**
	 * <b>Méthode principale</b> exécutant le programme.
	 * 
	 * @param args
	 * 		Les arguments passés en paramètre lors de l'exécution du programme.<br> Ils sont stockés dans un tableau de <code>String</code> et sont utilisés par le programme si besoin.
	 * 
	 * @exception InputMismatchException Déclanchée lorsque l'on saisi autre chose qu'un entier.
	 * @exception NullPointerException Déclanchée lorsque la valeur de l'entier demandé reste inchangée (donc à <code>null</code>).
	 * @exception Exception Déclanchée lorsque l'on rencontre une erreur lors du déroulement du programme de l'une des classes Main des autres packages.
	 * 
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Integer x = null;
		
		//Introduction
		System.out.println("Bienvenue dans SMDZ_NavalWar!");
		System.out.println("Nous sommes ravis de vous accueillir et espérns que vous vous y plairez!\nNous vous prions de suivre toutes les consignes qui vous serons communiquées au fur et à mesure de votre avancée. \n");
		System.out.println("Le jeu est disponible en deux modes: le mode console et le mode graphique. ");
		
		try
		{
			do
			{
				System.out.println("Si vous souhaitez le lancer en mode console, veuillez entrer 0 \nSi vous souhaitez le lancer en mode graphique, veuillez entrer 1 \nVous pouvez saisir 2 pour sortir du jeu.");
				
				x = sc.nextInt();
				
				if(x!=0 && x!=1 && x!=2)
				{
					sc.nextLine();
					System.out.println("Veuillez saisir un chiffre : 0, 1 ou 2");				
				}
				
			} while(x!=0 && x!=1 && x!=2);
		}
		
		catch(Exception e)
		{
			sc.nextLine();
			System.out.println("Vous avez entrez autre chose qu'un entier. Veuillez recommencer.");
			//e.printStackTrace();
		}
		
		if(x == 0)  //Le mode console
		{
			try 
			{
				//Main_Model.main(args);
				
				new Thread() {
			     public void run() {
			    	try 
			    	{
						Main_Model.main(args);
					} 
					
					catch (Exception e) {
						System.out.println("Impossible d'exécuter le programme");
						e.printStackTrace();
					}
			     }
			   }.start();
			  
			} 
			
			catch (Exception e) {
				System.out.println("Impossible d'exécuter le programme");
				//e.printStackTrace();
			}
		}
		
		else if(x == 1) //Le mode graphique
		{
			try 
			{
				//Main_View.main(args);
				
				new Thread() {
			     public void run() {
			    	try 
			    	{
						Main_View.main(args);
					} 
					
					catch (Exception e) {
						System.out.println("Impossible d'exécuter le programme");
						e.printStackTrace();
					}
			     }
			   }.start();
			  
			} 
			
			catch (Exception e) {
				System.out.println("Impossible d'exécuter le programme");
				//e.printStackTrace();
			}
		}
		
		else
		{
			System.out.println("SMDZ_NavalWar vous remercie d'être venu.");
			System.exit(0);
		}

	}

}

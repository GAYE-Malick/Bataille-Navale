package fr.smdz_navalWar.Main;

import java.util.InputMismatchException;
import java.util.Scanner;

import fr.smdz_navalWar.Model.Battlefield;
import fr.smdz_navalWar.Model.Boat;
import fr.smdz_navalWar.Model.HumanPlayer;
import fr.smdz_navalWar.Model.Player;
import fr.smdz_navalWar.Model.RandomPlayer;
import fr.smdz_navalWar.View.SeaView;

/**
 * <b>Main_Model est la classe principale en mode console.</b>
 * <p>
 * Elle permet de faire jouer en mode console, soit:
 * <ul>
 * <li>Un joueur humain contre un autre joueur humain</li>
 * <li>Un joueur humain contre un joueur aléatoire</li>
 * <li>Un joueur aléatoire contre un autre joueur aléatoire</li>
 * </ul>
 * Le choix des joueurs revient à l'utilisateur.
 * </p>
 * 
 * @see Main
 * @see Main_View
 * @see Battlefield
 * @see Boat
 * @see Player
 * @see HumanPlayer
 * @see RandomPlayer
 * @see SeaView
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Main_Model {

	/**
	 * <b>Méthode principale</b> exécutant le programme en mode console.
	 * 
	 * @param args
	 * 		Les arguments passés en paramètre lors de l'exécution du programme.<br> Ils sont stockés dans un tableau de <code>String</code> et sont utilisés par le programme si besoin.
	 * 
	 * @exception InputMismatchException Déclanchée lorsque l'on saisi autre chose qu'un entier.
	 * 
	 */
	public static void main(String[] args) {
		
		//TODO Les put et le isOver
		
		Scanner sc = new Scanner(System.in);
		Integer x = null;
		
		//Introduction
		System.out.println("Bienvenue dans le mode console de SMDZ_NavalWar!");
		
		//Création des champs de bataille
		Battlefield chB1= new Battlefield(10,10);
		Battlefield chB2 = new Battlefield(10,10);
		
		//Création des joueurs
		Player p1 = null;
		Player p2 = null;
		
		System.out.println("Il y a 2 types de joueurs: Humain et Random.");
		System.out.println("Nous vous proposons 3 modes de jeu: HvsH, HvsR et RvsR.");
		System.out.println("Entrez 0 pour: HvsH, 1 pour: HvsR et 2 pour: RvsR.");
		
		try
		{
			do
			{
				x = sc.nextInt();
				sc.nextLine();
				
				if(x!=0 && x!=1 && x!=2)
				{
					System.out.println("Veuillez saisir un chiffre : 0, 1 ou 2");				
				}
				
			} while(x!=0 && x!=1 && x!=2);
			

			if(x == 0)
			{
				System.out.println("Joueur 1, veuillez saisir votre nom!");
				String name1 = sc.nextLine();
				
				System.out.println("Joueur 2, veuillez saisir votre nom!");
				String name2 = sc.nextLine();
				
				p1 = new HumanPlayer(name1, chB1);
				p2 = new HumanPlayer(name2, chB2);
			}
			
			else if(x == 1)
			{
				sc.nextLine();
				System.out.println("Veuillez saisir votre nom!");
				String name = sc.nextLine();
				
				p1 = new HumanPlayer(name, chB1);
				p2 = new RandomPlayer(chB2);
			}
			
			else
			{
				p1 = new RandomPlayer(chB1);
				p2 = new RandomPlayer(chB2);
			}
			
			if(p1 != null && p2 != null) //La compilation continue seulement si les players sont différents de null
			{
				//Création des bateaux
				System.out.println("Vous disposez de 5 bateaux par flotte (par défaut).\n Un bateau de longueur 2, deux bateaux de longueur 3, un bateau de longueur 4 et un bateau de longueur 5.");
				System.out.println("Voulez-vous changer le nombre de bateaux ?");
				char y;
				
				do
				{
					System.out.println("Veuillez entrer: 'o'(Oui) ou 'n'(Non)!");
					String str = sc.nextLine();
					y = str.charAt(0);
				
				}while(y != 'o' && y != 'n');
				
				if(y == 'o')
				{
					System.out.println("Attention: Le nombre de bateaux et leurs caractéristiques seront les mêmes pour les deux joueurs!");
					System.out.println("Entrez le nombre de bateaux voulus.");
					System.out.println("Veuillez noter que le nombre saisi doit être compris entre 3 et 7.");
					Integer n;
					
					do
					{
						n = sc.nextInt();
						
						if(n < 3 || n > 7)
						{
							System.out.println("Veuillez saisir un nombre compris entre 3 et 7.");
						}
					
					}while(n < 3 || n > 7);
					
					for(int i = 1 ; i <= n ; i++)
					{
						System.out.println("Veuillez entrer la longueur du bateau "+ i + ". Veuillez noter que le nombre saisi doit être compris entre 2 et 10.");
						Integer l;
						
						do
						{
							l = sc.nextInt();
							
							if(l < 2 || l > 10)
							{
								System.out.println("Veuillez saisir un nombre compris entre 2 et 10.");
							}
							
						}while(l < 2 || l > 10);
						
						System.out.println("Joueur " + p1.toString());
						p1.decideCoordPut(new Boat(l));
						
						System.out.println("Joueur " + p2.toString());
						p2.decideCoordPut(new Boat(l));				
					}
					
				}
				
				else
				{
					//Placer les bateaux dans les champs de bataille
					System.out.println("Joueur " + p1.toString());
					p1.decideCoordPut(new Boat(2));
					p1.decideCoordPut(new Boat(3));
					p1.decideCoordPut(new Boat(3));
					p1.decideCoordPut(new Boat(4));
					p1.decideCoordPut(new Boat(5));
					
					System.out.println("Joueur " + p2.toString());
					p2.decideCoordPut(new Boat(2));	
					p2.decideCoordPut(new Boat(3));	
					p2.decideCoordPut(new Boat(3));	
					p2.decideCoordPut(new Boat(4));	
					p2.decideCoordPut(new Boat(5));					
				}
				
				//Créer la vue en mode console
				SeaView view1 = new SeaView("Mer", chB1, chB2);
				
				//Faire la boucle de jeu
				Player currentPlayer = p1;
				
				while( !chB1.isOver() && !chB2.isOver() )
				{
					if(currentPlayer == p1)
					{
						System.out.println("Joueur " + p1.toString());
						p1.decideCoordAim(chB2);
						currentPlayer = p2;
					}
					
					else
					{
						System.out.println("Joueur " + p2.toString());
						p2.decideCoordAim(chB1);
						currentPlayer = p1;
					}
				}
				
				//Annoncer le vainqueur s'il y a lieu
				if(chB1.isOver()) 
				{
					if(!chB2.isOver())
						System.out.println("Le vainqueur est le joueur " + chB2.getPlayer().toString());
					else
						System.out.println("Match nul! Il n'y a pas de vaiqueur.");
				}
				
				else
				{
					if(chB2.isOver())
						System.out.println("Le vainqueur est le joueur " + chB1.getPlayer().toString());
				}				
			}
			
		}
		
		catch(Exception e)
		{
			System.out.println("Vous avez entrez autre chose qu'un entier. Veuillez recommencer.");
			e.printStackTrace();
		}
		
		sc.close();
	}

}

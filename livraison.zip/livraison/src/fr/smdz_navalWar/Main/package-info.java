/**
 * <b> Package contenant les différentes classes Main </b>
 * 
 * @see Main
 * @see Main_Model
 * @see Main_View
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 * 
 */
package fr.smdz_navalWar.Main;
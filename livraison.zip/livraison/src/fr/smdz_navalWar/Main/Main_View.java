package fr.smdz_navalWar.Main;

import java.awt.Dimension;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

import fr.smdz_navalWar.Controller.ResizeImg;
import fr.smdz_navalWar.Model.Battlefield;
import fr.smdz_navalWar.Model.Boat;
import fr.smdz_navalWar.Model.HumanPlayer;
import fr.smdz_navalWar.Model.Obus;
import fr.smdz_navalWar.Model.Player;
import fr.smdz_navalWar.Model.RandomPlayer;
import fr.smdz_navalWar.View.BattlefieldPanel;
import fr.smdz_navalWar.View.SeaFrame;

/**
 * <b>Main_View est la classe principale en mode graphique.</b>
 * <p>
 * Elle permet de faire jouer un joueur humain contre un joueur random.
 * </p>
 * 
 * @see Main
 * @see Main_Model
 * @see Battlefield
 * @see Player
 * @see HumanPlayer
 * @see RandomPlayer
 * @see Boat
 * @see SeaFrame
 * @see BattlefieldPanel
 *  
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Main_View {

	/**
	 * <b>Méthode principale</b> exécutant le programme en mode graphique.
	 * 
	 * @param args
	 * 		Les arguments passés en paramètre lors de l'exécution du programme.<br> Ils sont stockés dans un tableau de <code>String</code> et sont utilisés par le programme si besoin.
	 * 
	 */
	public static void main(String[] args) throws Exception {
		
		// TODO Apply a look'n feel
		UIManager.setLookAndFeel(new NimbusLookAndFeel());
		
		String playerName = null;
		final int TAIL = 10;
		
		//La boîte de dialogue de départ
		JTextField player = new JTextField();
		
		JPanel panInfo = new JPanel();
	    panInfo.setLayout(new BoxLayout(panInfo, BoxLayout.PAGE_AXIS));
	    
	    panInfo.add(new JLabel("<html> <h4> Entrez votre nom </h4> </html>"));
	    player.setPreferredSize(new Dimension(100,25));
	    panInfo.add(player);
	    
	    panInfo.setBorder(BorderFactory.createTitledBorder("<html> <h2> Infos sur le joueur </h2> </html>")); //sur le jeu
        
	    String newImg = ResizeImg.resizedImg("src/images/navalWar_logo2.png", "src/images/navalWar_logo2_resized.png", 150, 150);
        
        ImageIcon icon = new ImageIcon(newImg);
        
	    JOptionPane startWlc = new JOptionPane(panInfo, JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_OPTION, icon); //YES_NO_OPTION
	    Integer fin = null;
	    
	    //Création de la boite de dialogue correspondante :
	 	JDialog dialog = startWlc.createDialog(null, "SMDZ-Prelude");
	 	dialog.setAlwaysOnTop(true);
	  
	 	dialog.setVisible(true);
	 	dialog.dispose();
	 		
	 	//Traitement de la valeur reçue :
		Object selectedValue = startWlc.getValue();
		if (selectedValue == null)
			fin = JOptionPane.CLOSED_OPTION;
	 
		if (selectedValue instanceof Integer)
			fin = ((Integer) selectedValue).intValue();

	    
	    if(fin == JOptionPane.OK_OPTION) {
	    		
	    	try
		    {
		    	//haut = Integer.parseInt(x.getText());
		    	//larg = Integer.parseInt(y.getText());
		    	playerName = player.getText();
		    }
		    catch(NumberFormatException e) //Si l'utilisateur entre autre chose que des nombres pour la hauteur et/ou la largeur des champs de bataille, on lui demande de relancer le programme.
		    { 
		    	JOptionPane.showMessageDialog(null,"<html> <h2> Vous n'avez pas saisi des dimensions correctes! Veuillez relancer le programme. </h2> </html>","SMDZ-Erreur", JOptionPane.PLAIN_MESSAGE);
		    }
	    	
		    //Les champs de bataille
	    	Battlefield chB1 = new Battlefield(TAIL, TAIL); //Battlefield(haut, larg);
			Battlefield chB2 = new Battlefield(TAIL, TAIL); //Battlefield(haut, larg);
			    	    
			HumanPlayer p1 = new HumanPlayer(playerName, chB1);
			RandomPlayer p2 = new RandomPlayer(chB2);
			    
			chB1.setPlayer(p1);
			chB2.setPlayer(p2);
			
			//L'ensemble de la flotte
			Boat bateau_de_longueur2 = new Boat(2); 
			Boat premier_bateau_de_longueur3 = new Boat(3); 
			Boat deuxieme_bateau_de_longueur3 = new Boat(3); 
			Boat bateau_de_longueur4 = new Boat(4); 
			Boat bateau_de_longueur5 = new Boat(5); 
			
			//La frame de la mer comportant les deux champs de bataille.    
			SeaFrame btfFrame = new SeaFrame(chB1, chB2);
			btfFrame.setLocationRelativeTo(null);
			btfFrame.setVisible(true);
			
			JOptionPane.showMessageDialog(btfFrame,"<html> <h3> Vous disposez de 5 bateaux. Il vous revient de les placer dans votre champ de bataille. "
					+ "<br>Si vous n'entrez aucun bateau, vous perdez. </h3> </html>","SMDZ-Message", JOptionPane.PLAIN_MESSAGE);
			
			JComboBox<Boat> boatList = new JComboBox<Boat>();
			boatList.addItem(bateau_de_longueur2);
			boatList.addItem(premier_bateau_de_longueur3);
			boatList.addItem(deuxieme_bateau_de_longueur3);
			boatList.addItem(bateau_de_longueur4);
			boatList.addItem(bateau_de_longueur5);
			
			for(int i = 5 ; i > 0 ; i--) //Le joueur humain place les 5 bateaux de sa flotte
			{				
				JComboBox<String> direc = new JComboBox<String>();
				direc.addItem("Verticale");
				direc.addItem("Horizontale");
				
				JComboBox<Integer> xl = new JComboBox<Integer>();
				JComboBox<Integer> yl = new JComboBox<Integer>();
				for(int j = 0 ; j < TAIL ; j++)
				{
					xl.addItem(j);
					yl.addItem(j);
				}
				
				JPanel panAddBoat = new JPanel();
				panAddBoat.setPreferredSize(new Dimension(500,400));
				panAddBoat.setLayout(new BoxLayout(panAddBoat, BoxLayout.PAGE_AXIS));
				
				panAddBoat.add(new JLabel("<html> <h4> Choisissez le bateau à placer </h4> </html>"));
			    panAddBoat.add(boatList);
				
			    panAddBoat.add(new JLabel("<html> <h4> Choisissez le numéro de la ligne des coordonnées de départ du bateau </h4> </html>"));
			    panAddBoat.add(xl);
			    
			    panAddBoat.add(new JLabel("<html> <h4> Choisissez le numéro de la colonne des coordonnées de départ du bateau </h4> </html>"));
			    panAddBoat.add(yl);
			    
			    panAddBoat.add(new JLabel("<html> <h4> Choisissez la direction du bateau </h4> </html>"));
			    panAddBoat.add(direc);
			    
			    panAddBoat.setBorder(BorderFactory.createTitledBorder("<html> <h5> Reste: " + i + " bateau(x) à placer ! </h5> </html>"));
			    
			    int res = JOptionPane.showOptionDialog(btfFrame, panAddBoat, "SIMS-Enregistrement des bateaux", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
			    
			    if(res == JOptionPane.OK_OPTION)
			    {
				    int indexB = boatList.getSelectedIndex();
				    
				    Boat b = (Boat)boatList.getSelectedItem();				    
				    boatList.removeItemAt(indexB);
				    
				    if(direc.getSelectedIndex() == 0)
				    {
				    	p1.put(b, (Integer)xl.getSelectedItem(), (Integer)yl.getSelectedItem(), true);
				    }
				    
				    else
				    {
				    	p1.put(b, (Integer)xl.getSelectedItem(), (Integer)yl.getSelectedItem(), false);
				    }
				    
				    p1.getChB().fireChange();
			    }    
			}
			
			p2.decideCoordPut(bateau_de_longueur2);
			p2.decideCoordPut(premier_bateau_de_longueur3);
			p2.decideCoordPut(deuxieme_bateau_de_longueur3);
			p2.decideCoordPut(bateau_de_longueur4);
			p2.decideCoordPut(bateau_de_longueur5);
		    
		    // TODO La boucle pour le jeu
		    Player currentPlayer = p1;
		    
		    while( !chB1.isOver() && !chB2.isOver())
		    {			    	
		    	if( currentPlayer == p1)
		    	{
			   		synchronized (chB2) {
		    		    try {
		    		        chB2.wait();
		    		    } catch (InterruptedException e) {
		    		        e.printStackTrace();
		    		    }
		    		}
		    		
		    		currentPlayer = p2;
		    	}
		    	
		    	else
		    	{
		    		currentPlayer.decideCoordAim(chB1);
		    		currentPlayer = p1;
		    	}
		    	
		    	btfFrame.getHeadHalf().setText("<html> <h3>Joueur 1: " + btfFrame.getChBmodel1().nbBoatSink() + " bateau(x) coulé(s) <br>Joueur 2: " + btfFrame.getChBmodel2().nbBoatSink() + " bateau(x) coulé(s) </h3></html>");
		    	
		    }
		    
		    if( chB1.isOver() )
		    	JOptionPane.showMessageDialog(btfFrame,"<html> <h2> Félicitations au joueur " + p2.toString() + " pour sa victoire. </h2> </html>","SMDZ-WinnerAnnoucement", JOptionPane.PLAIN_MESSAGE);
		     else if( chB2.isOver() )
		    	 JOptionPane.showMessageDialog(btfFrame,"<html> <h2> Félicitations au joueur " + p1.toString() + " pour sa victoire. </h2> </html>","SMDZ-WinnerAnnoucement", JOptionPane.PLAIN_MESSAGE);
		     else
		    	 JOptionPane.showMessageDialog(btfFrame,"<html> <h2> Il n'y a pas de vainqueur. C'est un match nul! </h2> </html>","SMDZ-WinnerAnnoucement", JOptionPane.PLAIN_MESSAGE);
		    
		     JOptionPane.showMessageDialog(btfFrame,"<html> <h2> AU REVOIR! </h2> <br/> Ce fut un plaisir. </html>","SMDZ-Au revoir", JOptionPane.PLAIN_MESSAGE);
		     btfFrame.dispose();
		    
		}
	    
	    else //Si l'utilisateur appuie sur annuler ou s'il ferme la boîte de dialogue, il arrête l'exécution du programme.
		{
			JOptionPane.showMessageDialog(null,"<html> <h2> AU REVOIR! </h2> <br/> Ce fut un plaisir. </html>","SMDZ-Au revoir", JOptionPane.PLAIN_MESSAGE);
			System.exit(1);
		}
	    
	}

}

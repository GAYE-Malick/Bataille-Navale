package fr.smdz_navalWar.Model;

/**
 * 
 * <b>Obus est la classe qui représente un tir lancé.</b>
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
public class Obus {

	/**
	 * <b>Constructeur de la classe Obus</b>
	 */
	public Obus() {
		
	}
	
}

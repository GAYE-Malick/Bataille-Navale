package fr.smdz_navalWar.Model;

/**
 * <b>Area est la classe qui représente une zone d'un champ de bataille.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un String <b>s</b> </li>
 * <li> Un Battlefield <b>chB</b> </li>
 * <li> Un Coord <b>coord</b> </li>
 * <li> Un Obus <b>o</b> </li>
 * <li> Un Boat <b>b</b> </li>
 * <li> Un boolean <b>touche</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link Area#put(Boat)} </b> </li>
 * <li> Un void <b> {@link Area#assault(Obus)} </b> </li> 
 * <li> Un String <b> {@link Area#toString()} </b> </li>
 * <li> Un Boat <b> {@link Area#getB()} </b> </li>
 * <li> Un Battlefield <b> {@link Area#getChB()} </b> </li>
 * <li> Un Coord <b> {@link Area#getCoord()} </b> </li>
 * <li> Un Obus <b> {@link Area#getO()} </b> </li>
 * <li> Un boolean <b> {@link Area#getTouche()} </b> </li>
 * <li> Un void <b> {@link Area#setTouche(boolean)} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité. 
 * </p>
 * 
 * @see Battlefield
 * @see Coord
 * @see Obus
 * @see Boat
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Area {

	/**
	 * La valeur à afficher dans le toString {@link Area#toString()}.
	 */
	private String s = " ";
	
	/**
	 * Le champ de bataille auquel appartient la zone.
	 */
	private Battlefield chB;
	
	/**
	 * La coordonnée ou l'emplacement de la zone.
	 */
	private Coord coord;
	
	/**
	 * L'obus(tir) à placer dans la zone si elle est attaquée {@link Area#assault(Obus)}.
	 */
	private Obus o;
	
	/**
	 * Le bateau à placer dans la zone s'il y a lieu {@link Area#put(Boat)}.
	 */
	private Boat b;
	
	/**
	 * Représente le "touché" d'une zone.<br>
	 * Vaut <code>false</code> par défaut car la zone est safe. Passe à <code>true</code> si la zone est attaquée donc "touchée".
	 */
	private boolean touche = false;
	
	/**
	 * <b>Constructeur de la classe Area</b>
	 * <p>
	 * Initialise l'obus o et le bateau b à null.
	 * </p>
	 * 
	 * @param chB
	 * 		Le champ de bataille auquel appartient la zone.
	 * @param x
	 * 		L'abscisse de la coordonnée de la zone.
	 * @param y
	 * 		L'ordonnée de la coordonnée de la zone.
	 */
	public Area(Battlefield chB, int x, int y) {
		
		this.chB = chB;
		this.coord = new Coord(x,y);
		this.o = null;
		this.b = null;
	}
	
	/**
	 * Ajoute un bateau(une partie du bateau) dans cette zone.
	 * 
	 * @param b
	 * 		Le bateau à placer.
	 */
	public void put(Boat b) {
		
		this.b = b;
	}
	
	/**
	 * Attaque une zone.
	 * 
	 * @param o
	 * 		L'obus(tir) à lancer.
	 */
	public void assault(Obus o) { //La méthode illustrant l'attaque d'une zone
		
		this.o = o;
		if(this.b != null)
		{
			this.s = "X";
		}
		else
		{
			this.s = "!";
		}
		this.touche = true;
	}
	
	/**
	 * Affiche une aire en mode console.
	 */
	@Override
	public String toString() {
		
		String str = " " + this.s + " |";
		
		return str;
	}
	
	//GETTERS ET SETTERS	
	/**
	 * Permet d'accéder au champ de bataille auquel la zone appartient.
	 * 
	 * @return chB-Le champ de bataille.
	 */
	public Battlefield getChB() {
		return this.chB;
	}

	/**
	 * Permet d'accéder à l'emplacement de la zone dans le champ de bataille.
	 * 
	 * @return coord-Les coordonnées de la zone.
	 */
	public Coord getCoord() {
		return this.coord;
	}
	
	/**
	 * Permet d'accéder à l'obus de la zone.
	 * 
	 * @return o-L'obus de la zone.
	 */
	public Obus getO() {
		return this.o;
	}

	/**
	 * Permet d'accéder au bateau de la zone.
	 * 
	 * @return b-Le bateau de la zone.
	 */
	public Boat getB() {
		return this.b;
	}
	
	/**
	 * Permet d'accéder à l'attribut illustrant le "touché" de la zone.
	 * 
	 * @return <code>true</code> si la zone est touchée et <code>false</code> si non.
	 */
	public boolean getTouche() {
		return this.touche;
	}
	
	/**
	 * Permet de modifier l'attribut illustrant le "touché" de la zone.
	 * 
	 * @param touch
	 * 		La nouvelle valeur de touche.
	 */
	public void setTouche(boolean touch) {
		
		this.touche = touch;
	}
	
}

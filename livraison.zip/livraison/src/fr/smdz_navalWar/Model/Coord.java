package fr.smdz_navalWar.Model;

/**
 * <b>Coord est la classe qui représente une coordonnée.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Deux int <b>x</b> et <b>y</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un int <b> {@link Coord#getX()} </b> </li>
 * <li> Un int <b> {@link Coord#getY()} </b> </li>
 * <li> Une String <b> {@link Coord#toString()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité. 
 * </p>
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
public class Coord {

	/**
	 * L'abscisse x et l'ordonnée y.
	 */
	private int x, y;
	
	/**
	 * <b>Constructeur de la classe Coord</b>
	 * 
	 * @param x
	 * 		L'abscisse.
	 * @param y
	 * 		L'ordonnée.
	 */
	public Coord(int x, int y) {
		
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Affiche une coordonnée.
	 */
	@Override
	public String toString() {
		
		return "(" + this.x + "," + this.y + ")";
	}
	
	//GETTERS ET SETTERS
	/**
	 * Permet d'accéder à l'abscisse.
	 * 
	 * @return L'abscisse.
	 */
	public int getX() {
		
		return this.x;
	}
	
	/** 
	 * Permet d'accéder à l'ordonnée.
	 * 
	 * @return L'ordonnée.
	 */
	public int getY() {
		return this.y;
	}
	
}

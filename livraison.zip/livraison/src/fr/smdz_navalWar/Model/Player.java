package fr.smdz_navalWar.Model;

/**
 * <b>Player est l'interface stockant les différentes méthodes requises à un joueur.</b>
 * 
 * <p>
 * Elle stocke les méthodes suivantes: 
 * <ul>
 * <li> Un void <b> {@link Player#aim(Battlefield, int, int, Obus)} </b> </li>
 * <li> Un void <b> {@link Player#decideCoordAim(Battlefield)} </b> </li>
 * <li> Un void <b> {@link Player#decideCoordPut(Boat)} </b> </li>
 * <li> Un void <b> {@link Player#put(Boat, int, int, boolean)} </b> </li>
 * </ul>
 * </p>
 * 
 * @see HumanPlayer
 * @see RandomPlayer
 * @see Battlefield
 * @see Boat
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
public interface Player {
	
	/**
	 * Permet au joueur de choisir la zone où placer un bateau.
	 *
	 * @param b
	 * 		Le bateau à placer.
	 */
	public void decideCoordPut(Boat b);
	
	/**
	 * Permet au joueur de placer un bateau dans le champ de bataille
	 * 
	 * @param b
	 * 		Le bateau à placer
	 * @param x
	 * 		L'abscisse de la coordonnée de départ du bateau.
	 * @param y
	 * 		L'ordonnée de la coordonnée de départ du bateau.
	 * @param dir
	 * 		La direction du bateau.
	 */
	public void put(Boat b, int x, int y, boolean dir);
	
	/**
	 * Permet au joueur de choisir la zone à attaquer.
	 *
	 * @param chB
	 * 		Le champ de bataille à attaquer.
	 */
	public void decideCoordAim(Battlefield chB);
	
	/**
	 * Permet au joueur d'attaquer un champ de bataille.
	 * 
	 * @param chB
	 * 		Le champ de bataille à attaquer.
	 * @param o
	 * 		L'obus(tir) à lancer.
	 */
	public void aim(Battlefield chB, int x, int y, Obus o);
	
}

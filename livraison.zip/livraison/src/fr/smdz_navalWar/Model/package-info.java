/**
 * <b>Package regroupant les classes du modèle.</b>
 * 
 * @see AbstractListenableModel
 * @see Area
 * @see Battlefield
 * @see Boat
 * @see Coord
 * @see HumanPlayer
 * @see ModelListener
 * @see Obus
 * @see Player
 * @see RandomPlayer
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
package fr.smdz_navalWar.Model;

import fr.smdz_navalWar.Controller.AbstractListenableModel;
import fr.smdz_navalWar.Controller.ModelListener;

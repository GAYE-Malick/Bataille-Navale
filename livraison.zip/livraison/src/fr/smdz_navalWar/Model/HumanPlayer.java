package fr.smdz_navalWar.Model;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * <b>HumanPlayer est la classe qui représente un joueur humain.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un String <b>name</b> </li>
 * <li> Un Battlefield <b>chB</b> </li>
 * <li> Une ArrayList de Coord <b>coordPut</b> </li>
 * <li> Une ArrayList de Coord <b>coordAssault</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link HumanPlayer#aim(Battlefield, int, int, Obus)} </b> </li>
 * <li> Un boolean <b> {@link HumanPlayer#contain(ArrayList, Coord)} </b> </li> 
 * <li> Un void <b> {@link HumanPlayer#decideCoordAim(Battlefield)} </b> </li>
 * <li> Un void <b> {@link HumanPlayer#decideCoordPut(Boat)} </b> </li>
 * <li> Un Battlefield <b> {@link HumanPlayer#getChB()} </b> </li>
 * <li> Un String <b> {@link HumanPlayer#getName()} </b> </li>
 * <li> Un void <b> {@link HumanPlayer#put(Boat, int, int, boolean)} </b> </li>
 * <li> Un String <b> {@link HumanPlayer#toString()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité. 
 * </p>
 * 
 * @see Player
 * @see Battlefield
 * @see Coord
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
public class HumanPlayer implements Player{

	/**
	 * Le nom du joueur.
	 */
	private String name;
	
	/**
	 * Le champ de bataille du joueur.
	 */
	private Battlefield chB;
	
	/**
	 * L'ensemble des coordonnées possibles pour placer un bateau.
	 */
	private ArrayList<Coord> coordPut = new ArrayList<Coord>();
	
	/**
	 * L'ensemble des coordonnées possibles pour attaquer un champ de bataille.
	 */
	private ArrayList<Coord> coordAssault = new ArrayList<Coord>();
	
	private Scanner sc = new Scanner(System.in);
	
	/**
	 * <b>Constructeur de la classe HumanPlayer</b>
	 * 
	 * @param n
	 * 		Le nom du joueur
	 * @param chB
	 * 		Le champ de bataille du joueur
	 */
	public HumanPlayer(String n, Battlefield chB) {
		
		this.name = n;
		this.chB = chB;
		this.chB.setPlayer(this);
		for(int i = 0 ; i < this.chB.getHaut() ; i++) 
		{
			for(int j = 0 ; j < this.chB.getLarg() ; j++) 
			{
				this.coordPut.add(new Coord(i,j));
				this.coordAssault.add(new Coord(i,j));
			}
		}
	}
	
	/**
	 * Permet au HumanPlayer de choisir la zone où placer un bateau.
	 */
	@Override
	public void decideCoordPut(Boat b) {
		
		int x, y,z;
		boolean dir = true;
		Coord c;
		
		do
		{	
			//System.out.println("\nJoueur " + this.toString());
			System.out.println("Veuillez entrer les coordonnées de la zone de départ du bateau " + b.toString());
			System.out.println("Le x: ");
			x = sc.nextInt();
			sc.nextLine();
			
			System.out.println("Le y: ");
			y = sc.nextInt();
			sc.nextLine();
			
			c = new Coord(x,y);
			
			if(this.chB.getBoard()[x][y].getB() != null)
			{
				System.out.println(" Vous avez déjà posé un bateau dans la zone " + c.toString() + " ! Essayez-en une autre!");
			}
			
			else
			{
				do
				{	
					System.out.println("Veuillez choisir la direction du bateaubateau " + b.toString());
					System.out.println("Entrez 0 pour l'horizontal et 1 pour la verticale!");
					z = sc.nextInt();
					sc.nextLine();
					
					if( z!=0 && z!=1  )
						System.out.println(" Vous avez saisit une mauvaise information! Veuillez saisir 0 ou 1!");
				
				} while( z!=0 && z!=1 );
				
				if( z==0 )
					dir = false; //Si l'utilisateur saisit 0, il place le bateau à l'horizontal.
				
				if(!this.chB.isValid(b, x, y, dir))
					System.out.println("La position n'est pas valide ! Essayez-en une autre!");
			}
			
		} while( (this.chB.getBoard()[x][y].getB() != null) || (!this.chB.isValid(b, x, y, dir)) );
		
		this.put(b, x, y, dir);
	}
	
	/**
	 * Permet au HumanPlayer de placer un bateau dans son champ de bataille.
	 */
	@Override
	public void put(Boat b, int x, int y, boolean dir) {
		
		this.chB.put(b, x, y, dir);
	}
	
	/**
	 * Permet au HumanPlayer de choisir la zone à attaquer.
	 */
	@Override
	public void decideCoordAim(Battlefield chB) {
		
		if(chB != this.chB) //Si le joueur attaque son propre camp, on lui demande de réessayer
		{
			int x, y;
			Coord c;
				
			do
			{	
				System.out.println("Veuillez entrer les coordonnées de la zone à viser: ");
				System.out.println("Le x: ");
				x = sc.nextInt();
				sc.nextLine();
				
				System.out.println("Le y: ");
				y = sc.nextInt();
					
				c = new Coord(x,y);
					
				if( !this.contain(this.coordAssault, c) )
					System.out.println(" Vous avez déjà visé la zone " + c.toString() + " ! Essayez-en une autre!");
				
			} while( !this.contain(this.coordAssault, c) );
				
			this.coordAssault.remove(c);
				
			this.aim(chB, x, y, new Obus());
		}
		
		else 
		{
			System.out.println(" Vous ne pouvez pas vous auto-attaquer! Attaquez le champ adverse!");
		}
	}
	
	/**
	 * Permet au HumanPlayer d'attaquer un champ de bataille.
	 */
	@Override
	public void aim(Battlefield chB, int x, int y, Obus o) {
		
		chB.assault(x, y, o); //La méthode attaque du champ de bataille gère l'attaque.
	}
	
	/**
	 * Vérifie si une coordonnée appartient à une liste de coordonnées.
	 * 
	 * @param listC
	 * 		La liste dans laquelle la coordonnée est recherchée.
	 * @param c
	 * 		La coordonnée recherchée.
	 * @return <code>true</code> si la coordonnée est dans la liste <code>false</code> si non.
	 */
	public boolean contain(ArrayList<Coord> listC, Coord c) {
		
		boolean isIn = false;
		
		for(int i = 0 ; i < listC.size() ; i++)
		{
			if( (c.getX() == listC.get(i).getX()) && (c.getY() == listC.get(i).getY()) )
			{
				isIn = true;
				break;
			}
		}
		
		return isIn;
	}
	
	/**
	 * Affiche le nom du joueur.
	 */
	@Override
	public String toString() {
		
		if(this.name == null)
			return "Humain Inconnu car Sans Nom";
		if(this.name.length()>1)			
			return "Humain " + this.name.substring(0, 1).toUpperCase() + this.name.substring(1) ;
		else
			return " ";
	}
	
	//GETTERS ET SETTERS
	/**
	 * Permet d'accéder au nom du joueur.
	 * 
	 * @return Le nom du joueur
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Permet d'accéder au champ de bataille du joueur.
	 * 
	 * @return Le champ de bataille du joueur. 
	 */
	public Battlefield getChB() {
		return this.chB;
	}
	
}

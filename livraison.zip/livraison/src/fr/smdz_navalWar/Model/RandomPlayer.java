package fr.smdz_navalWar.Model;

import java.util.ArrayList;
import java.util.Random;

/**
 * <b>RandomPlayer est la classe qui représente un joueur random(aléatoire).</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un Battlefield <b>chB</b> </li>
 * <li> Une ArrayList de Coord <b>coordPut</b> </li>
 * <li> Une ArrayList de Coord <b>coordAssault</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link RandomPlayer#aim(Battlefield, int, int, Obus)} </b> </li>
 * <li> Un boolean <b> {@link RandomPlayer#contain(ArrayList, Coord)} </b> </li>
 * <li> Un Boat <b> {@link RandomPlayer#coordPutPoss(Boat)} </b> </li>
 * <li> Un void <b> {@link RandomPlayer#decideCoordAim(Battlefield)} </b> </li>
 * <li> Un void <b> {@link RandomPlayer#decideCoordPut(Boat)} </b> </li>
 * <li> Un void <b> {@link RandomPlayer#initCoords()} </b> </li>
 * <li> Un void <b> {@link RandomPlayer#put(Boat, int, int, boolean)} </b> </li>
 * <li> Un String <b> {@link RandomPlayer#toString()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité. 
 * </p>
 * 
 * @see Player
 * @see Battlefield
 * @see Coord
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
public class RandomPlayer implements Player{

	private Random rand = new Random();
	
	/**
	 * Le champ de bataille du joueur.
	 */
	private Battlefield chB;
	
	/**
	 * L'ensemble des coordonnées possibles pour placer un bateau.
	 */
	private ArrayList<Coord> coordPut = new ArrayList<Coord>();
	
	/**
	 * L'ensemble des coordonnées possibles pour attaquer un champ de bataille.
	 */
	private ArrayList<Coord> coordAssault = new ArrayList<Coord>();
	
	/**
	 * <b>Constructeur de la classe RandomPlayer</b>
	 * 
	 * @param chB
	 * 		Le champ de bataille du joueur.
	 */
	public RandomPlayer(Battlefield chB) {
		
		this.chB = chB;
		this.chB.setPlayer(this);
		
		this.initCoords();
	}
	
	/**
     * Initialise la liste des coordonnées possibles où placer un bateau et celle des coordonnées possibles à attaquer.
     */
    public void initCoords() {
    	
    	for(int i = 0 ; i < this.chB.getHaut() ; i++) 
		{
			for(int j = 0 ; j < this.chB.getLarg() ; j++) 
			{
				this.coordPut.add(new Coord(i,j));
				this.coordAssault.add(new Coord(i,j));
			}
		}
    }
    
    /**
     * Permet de choisir un bateau parmi ceux possibles en fonction des coordonnées de départ et de la direction.
     * 
     * @param b
     * 		Le bateau à placer.
     * @return Le bateau choisi.
     */
    public Boat coordPutPoss(Boat b) {
    	
    	ArrayList<Coord> coordPoss = new ArrayList<Coord>();
    	ArrayList<Boat> bList = new ArrayList<Boat>();
    	
    	for(Coord c : this.coordPut)
    	{
    		Boat b1 = new Boat(b.getL());
    		if(this.chB.isValid(b, c.getX(), c.getY(), false))
    		{
    			b1.setDir(false);
    			b1.setCoord(this.chB.coordPoss(b.getL(), c.getX(), c.getY(), false));
    			bList.add(b1);
    			coordPoss.add(c);
    		}
    		
    		if(this.chB.isValid(b, c.getX(), c.getY(), true))
    		{
    			b1.setDir(true);
    			b1.setCoord(this.chB.coordPoss(b.getL(), c.getX(), c.getY(), true));
    			bList.add(b1);
    			coordPoss.add(c);
    		}
    	}
    	
    	return bList.get(rand.nextInt(bList.size()));
    }
    
    
    /**
	 * Permet au RandomPlayer de choisir la zone où placer un bateau.
	 */
    @Override
	public void decideCoordPut(Boat b) {
		
    	Boat b2 = this.coordPutPoss(b);
		Coord c1 = b2.getCoord().get(0);
		
		//dir = true lorsque le bateau est à la verticale 
		//dir = false lorsque le bateau est à l'horizontal
		if(c1 != null)
			this.put(b2, c1.getX(), c1.getY(), b2.isDir());
    	
	}
	
	/*
	 * Permet au RandomPlayer de placer un bateau dans son champ de bataille
	 */
    @Override
	public void put(Boat b, int x, int y, boolean dir) { //Le faire choisir aussi randomly s'il veut vert ou horiz
		
		this.chB.put(b, x, y, dir);
	}
    
    /**
	 * Permet au RandomPlayer de choisir la zone à attaquer.
	 */
	@Override
	public void decideCoordAim(Battlefield chB) {
		
		if( !this.coordAssault.isEmpty() )
		{
			Coord c;
			int x = rand.nextInt(this.coordAssault.size());
			
			c = this.coordAssault.get(x);
			
			this.coordAssault.remove(x); //On retire c de l'ensemble des coordonées pas encore visées
			
			this.aim(chB, c.getX(), c.getY(), new Obus());
		}
		
	}
		
    /**
	 * Permet au RandomPlayer d'attaquer un champ de bataille.
	 */
	@Override
	public void aim(Battlefield chB, int x, int y, Obus o) { //Vise la zone de coordonées x,y du champ de bataille de l'adversaire
		
		chB.assault(x, y, o); //La méthode attaque du champ de bataille gère l'attaque
	}
	
	/**
	 * Vérifie si une coordonnée appartient à une liste de coordonnées.
	 * 
	 * @param listC
	 * 		La liste dans laquelle la coordonnée est recherchée.
	 * @param c
	 * 		La coordonnée recherchée.
	 * @return ret L'indice de la coordonnée dans la liste.
	 */
	public int contain(ArrayList<Coord> listC, Coord c) {
		
		Integer ret = null;
		
		for(int i = 0 ; i < listC.size() ; i++)
		{
			if( (c.getX() == listC.get(i).getX()) && (c.getY() == listC.get(i).getY()) )
			{
				ret = i;
				break;
			}
		}
	
		return ret;
	}
	
	/**
	 * Affiche le numéro du random player.
	 */
	@Override
	public String toString() {
		return "Random " + this.hashCode() ;
	}
	
}

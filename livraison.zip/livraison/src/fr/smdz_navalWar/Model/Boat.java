package fr.smdz_navalWar.Model;

import java.util.ArrayList;

/**
 * <b>Boat est la classe qui représente un bateau.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un int <b>l</b> </li>
 * <li> Un boolean <b>dir</b> </li>
 * <li> Une ArrayList de Coord <b>coord</b> </li>
 * <li> Une ArrayList d'Area <b>plageArea</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Une ArrayList de Coord <b> {@link Boat#getCoord()} </b> </li>
 * <li> Un int <b> {@link Boat#getL()} </b> </li>
 * <li> Une ArrayList d'Area <b> {@link Boat#getPlageArea()} </b> </li>
 * <li> Une boolean <b> {@link Boat#isDir()} </b> </li>
 * <li> Un void <b> {@link Boat#setCoord(ArrayList)} </b> </li>
 * <li> Un void <b> {@link Boat#setDir(boolean)} </b> </li>
 * <li> Une boolean <b> {@link Boat#sinkBoat()} </b> </li>
 * <li> Un String <b> {@link Boat#toString()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité. 
 * </p>
 * 
 * @see Area
 * @see Coord
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
public class Boat {

	/**
	 * La longueur du bateau.
	 */
	private int l;
	
	/**
	 * La direction du bateau.
	 */
	private boolean dir;
	
	/**
	 * Les coordonnées du bateau.
	 */
	private ArrayList<Coord> coord = new ArrayList<Coord>();
	
	/**
	 * La plage de zone sur laquelle s'étend le bateau.
	 */
	private ArrayList<Area> plageArea = new ArrayList<Area>();
	
	/**
	 * <b>Constructeur de la classe Boat</b>
	 * 
	 * @param l
	 * 		La longueur du bateau.
	 */
	public Boat(int l) {
		
		this.l = l;
	}
	
	/**
	 * Vérifie si le bateau est coulé.<br>
	 * Vérifie si toutes les zones qui contiennent le bateau ont été touchées.
	 * 
	 * @return <code>true</code> si le bateau est coulé et <code>false</code> si non.
	 */
	public boolean sinkBoat() { //Vérifie si le bateau est coulé
		
		for(Area a : this.plageArea)
		{
			if(a.getO() == null)
				return false;
		}
		
		return true;		
	}
	
	/**
	 * Retourne la longueur et les coordonnées d'un bateau.
	 */
	@Override
	public String toString()
	{
		if(this.coord.size() != 0)
			return "Bateau de longueur " + this.l + " et de coordonnées [" + this.coord.get(0).toString() + ":" + this.coord.get(this.coord.size() - 1) + "]";
		else
			return "Bateau de longueur " + this.l;
	}
	
	//GETTERS ET SETTERS
	/**
	 * Permet d'accéder à la direction d'un bateau.
	 * 
	 * @return La direction d'un bateau.
	 */
	public boolean isDir() {
		return this.dir;
	}

	/**
	 * Permet d'accéder à la longueur du bateau.
	 * 
	 * @return La longueur du bateau.
	 */
	public int getL() {
		return this.l;
	}

	/**
	 * Permet d'accéder à l'ensemble des coordonées du bateau.
	 * 
	 * @return L'ensemble des coordonées du bateau.
	 */
	public ArrayList<Coord> getCoord() {
		return this.coord;
	}

	/**
	 * Permet d'accéder à la plage de zones contenant le bateau.
	 * 
	 * @return L'ensemble des zones contenant le bateau.
	 */
	public ArrayList<Area> getPlageArea() {
		return this.plageArea;
	}
	
	/**
	 * Permet de modifier la direction d'un bateau.
	 * 
	 * @param dir
	 * 		La nouvelle direction du bateau.
	 */
	public void setDir(boolean dir) {
		this.dir = dir;
	}
	
	/**
	 * Permet de modifier la liste des coordonnées du bateau.
	 * 
	 * @param coord
	 * 		La nouvelle liste de coordonnées du bateau.
	 */
	public void setCoord(ArrayList<Coord> coord) {
		this.coord = coord;
	}	
}

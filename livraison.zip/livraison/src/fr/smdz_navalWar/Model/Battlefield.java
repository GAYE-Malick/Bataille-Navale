package fr.smdz_navalWar.Model;

import java.util.ArrayList;

import fr.smdz_navalWar.Controller.AbstractListenableModel;

/**
 * <b>Battlefield est la classe qui représente un champ de bataille.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Deux int <b>haut</b> et <b>larg</b> </li>
 * <li> Un tableau d'Area <b>board</b> </li>
 * <li> Un Player <b>player</b> </li>
 * <li> Une ArrayList de Boat <b>boatList</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link Battlefield#put(Boat, int, int, boolean)} </b> </li>
 * <li> Un void <b> {@link Battlefield#assault(int, int, Obus)} </b> </li>
 * <li> Un boolean <b> {@link Battlefield#boardFull()} </b> </li>
 * <li> Un boolean <b> {@link Battlefield#canPut(Boat, int, int, boolean)} </b> </li>
 * <li> Une ArrayList de Coord <b> {@link Battlefield#coordPoss(int, int, int, boolean)} </b> </li>
 * <li> Un boolean <b> {@link Battlefield#coordValids(Coord)} </b> </li>
 * <li> Un Area[][] <b> {@link Battlefield#getBoard()} </b> </li>
 * <li> Une ArrayList de Boat <b> {@link Battlefield#getBoatList()} </b> </li>
 * <li> Un int <b> {@link Battlefield#getHaut()} </b> </li>
 * <li> Un int <b> {@link Battlefield#getLarg()} </b> </li>
 * <li> Un Player <b> {@link Battlefield#getPlayer()} </b> </li>
 * <li> Un boolean <b> {@link Battlefield#isOver()} </b> </li>
 * <li> Un boolean <b> {@link Battlefield#isValid(Boat, int, int, boolean)} </b> </li>
 * <li> Un int <b> {@link Battlefield#nbBoatSink()} </b> </li>
 * <li> Un void <b> {@link Battlefield#setPlayer(Player)} </b> </li>
 * <li> Un boolean <b> {@link Battlefield#sinkAllBoat()} </b> </li>
 * <li> Un String <b> {@link Battlefield#toString()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité. 
 * </p>
 * 
 * @see Area
 * @see Player
 * @see Boat
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Battlefield extends AbstractListenableModel{

	/**
	 * Les dimensions du champ de bataille.<br>
	 * La hauteur et la largeur.
	 */
	private int haut, larg;
	
	/**
	 * L'ensemble des zones du champ de bataille.
	 */
	private Area board[][];
	
	/**
	 * Le joueur à qui appartient le champ de bataille.
	 */
	private Player player;
	
	/**
	 * L'ensemble des bateaux(la flotte) du champ de bataille.
	 */
	private ArrayList<Boat> boatList = new ArrayList<Boat>();
	
	/**
	 * <b>Constructeur de la classe Battlefield</b>
	 * 
	 * @param l
	 * 		La hauteur du champ de bataille.
	 * @param col
	 * 		La largeur du champ de bataille.
	 */
	public Battlefield(int l, int col) { //On initialise le champ de bataille
		
		this.haut = l;
		this.larg = col;
		this.board = new Area[this.haut][this.larg];
		for(int i = 0 ; i < this.haut ; i++) 
		{
			for(int j = 0 ; j < this.larg ; j++) 
			{
				this.board[i][j] = new Area(this, i,j);
			}
		}
		
	}
	
	/**
	 * Place un bateau dans le champ de bataille.
	 * 
	 * @param b
	 * 		Le bateau à placer.
	 * @param x
	 * 		L'abscisse de départ du bateau.
	 * @param y
	 * 		L'ordonnée de départ du bateau.
	 * @param dir
	 * 		La direction du bateau.
	 */
	public void put(Boat b, int x, int y, boolean dir) { //La méthode qui illustre l'action de mettre un bateau dans le champ de bataille
		
		if(this.isValid(b, x, y, dir))
		{
			this.boatList.add(b); //On ajoute le bateau à la liste de bateaux du champ de bataille
			b.setDir(dir);
			b.setCoord(this.coordPoss(b.getL(), x, y, dir)); //On ajoute la plage de coordonées sur laquelle s'étend le bateau.
			
			if(dir) //Si le bateau est à la verticale, on exécute les instructions ci-dessous ↓↓↓
			{
				for(int i = 0 ; i < b.getL() ; i++) {
					this.board[x+i][y].put(b); //On ajoute une référence au bateau sur la plage de zone sur laquelle s'étend le bateau en itérant sur les lignes
					b.getPlageArea().add(this.board[x+i][y]); //On ajoute la plage de zones sur laquelle s'étend le bateau en itérant sur les lignes
				}
			}
					
			else //S'il est à l'horizontal, on exécute les instructions ci-dessous ↓↓↓
			{
				for(int i = 0 ; i < b.getL() ; i++) {
					this.board[x][y+i].put(b); //On ajoute une référence au bateau sur la plage de zone sur laquelle s'étend le bateau en itérant sur les colonnes
					b.getPlageArea().add(this.board[x][y+i]); //On ajoute la plage de zones sur laquelle s'étend le bateau en itérant sur les colonnes
				}
			}		
			//this.fireChange();	
		}
	}
	
	/**
	 * Attaque un champ de bataille
	 * 
	 * @param x
	 * 		L'abscisse de la zone à attaquer.
	 * @param y
	 * 		L'ordonnée de la zone à attaquer.
	 * @param o
	 * 		L'obus(tir) à lancer.
	 */
	public void assault(int x, int y, Obus o) {
		
		if( this.board[x][y].getO() == null ) //Si la zone n'a pas encore été touchée, on l'attaque
		{	
			this.board[x][y].assault(o);
			this.fireChange();
			this.board[x][y].setTouche(true);
		}
	}
	
	/**
	 * Vérifie si le joueur a perdu.<br>
	 * Retourne <code>true</code> si tous les bateaux du champ de bataille ont coulé ou si toutes les zones du champ de bataille ont été touchées.<br>
	 * Retourne <code>false</code> si non. <br>
	 * 
	 * <h4>
	 * Veuillez noter qu'il retourne <code>true</code> si vous n'avez aucun bateau dans le champ de bataille.<br>
	 * On considère que vous avez perdu si vous n'avez placé aucun bateau.
	 * </h4>
	 * 
	 * @return <code>true</code> si le joueur a perdu et <code>false</code> si non.
	 */
	public boolean isOver() { //Vérifie si tous les bateaux du champ de bataille sont coulés
		
		/*
		if(this.boatList.isEmpy()) //Si vous n'avez aucun bateau, il renvoie false.
		{
			return false;
		}
		else
		*/
		
		if(this.sinkAllBoat()) //Si tous les bateaux sont coulés
		{
			return true;
		}
		
		else if(this.boardFull()) //Si toutes les cases ont été touchées
		{
			return true;
		}
		
		else
		{
			return false;
		}
	}
	
	/**
	 * Vérifie si des coordonnées sont valides, c'est-à-dire si la zone correspondante est vide.
	 * 
	 * @param c
	 * 		Les coordonnées de la zone à vérifier.
	 * @return <code>true</code> si la zone est vide et <code>false</code> si non.
	 */
	public boolean coordValids(Coord c) {
		
		if(this.board[c.getX()][c.getY()].getB() != null)
			return false;
		else
			return true;
		
	}
	
	/**
	 * Retourne les coordonnées possibles du bateau de taille "tail" à partir de la position de départ et dans la direction passées en paramètre.
	 * 
	 * @param tail
	 * 		La taille du bateau.
	 * @param x
	 * 		L'abscisse de départ du bateau.
	 * @param y
	 * 		L'ordonnée de départ du bateau.
	 * @param dir
	 * 		La direction du bateau.
	 * @return Les coordonnées possibles.
	 */
	public ArrayList<Coord> coordPoss(int tail, int x, int y, boolean dir){
		
		ArrayList<Coord> possCoord = new ArrayList<Coord>();
		
		if(dir) //Si le bateau est à la verticale, on exécute les instructions ci-dessous ↓↓↓
		{
			for(int i = 0 ; i < tail ; i++) {
				possCoord.add(new Coord(x+1,y));
			}
		}
		
		else //S'il est à l'horizontal, on exécute les instructions ci-dessous ↓↓↓
		{
			for(int i = 0 ; i < tail ; i++) {
				possCoord.add(new Coord(x,y+1));
			}
		}
		
		return possCoord;
	}
	
	/**
	 * Vérifie si l'on peut mettre un bateau à partir de la position de départ et dans la direction passées en paramètre.<br>
	 * Vérifie si les zones possibles sont vides.
	 * 
	 * @param b
	 * 		Le bateau à placer.
	 * @param x
	 * 		L'abscisse de départ du bateau.
	 * @param y
	 * 		L'ordonnée de départ du bateau.
	 * @param dir
	 * 		La direction du bateau.
	 * @return <code>true</code> si toutes les zones possibles sont vides et <code>false</code> si non.
	 */
	public boolean canPut(Boat b, int x, int y, boolean dir) {
		
		for(Coord c : this.coordPoss(b.getL(), x, y, dir) )
		{
			if(!this.coordValids(c))
			{
				return false;
			}
		}
		
		return true;
		
	}
	
	/**
	 * Vérifie si la position du bateau est valide.<br>
	 * Elle vérifie en premier lieu si la longueur du bateau entre dans les dimension du champ de bataille.<br>
	 * En second lieu, elle vérifie que la plage de coordonnées sur laquelle veut être placer le bateau est valide(vide).
	 * 
	 * @param b
	 * 		Le bateau à placer dans le champ de bataille.
	 * @param x
	 * 		L'abscisse de la coordonnée de départ du bateau.
	 * @param y
	 * 		L'ordonnée de la coordonnée de départ du bateau.
	 * @param dir
	 * 		La direction du bateau.
	 * @return <code>true</code> si la position est valide <code>false</code> si non.
	 */
	public boolean isValid(Boat b, int x, int y, boolean dir) {
		
		if(dir)
		{
			if( (0 < b.getL() && b.getL() <= this.haut) && (x+b.getL() <= this.haut) )
			{
				return this.canPut(b, x, y, dir);
			}
			else
				return false;
		}
		
		else
		{
			if( (0 < b.getL() && b.getL() <= this.larg) && (y+b.getL() <= this.larg) )
			{
				return this.canPut(b, x, y, dir);
			}
			else
				return false;
		}		
	}
	
	/**
	 * Vérifie si tous les bateaux du champ de bataille sont coulés
	 * 
	 * @return <code>true</code> si tous les bateaux sont coulés et <code>false</code> si non.
	 */
	public boolean sinkAllBoat() {
		
		for(Boat b : this.boatList ) //Vérifie l'état de chaque bateau du champ de bataille (s'il est coulé ou pas)
		{ 
			if(!b.sinkBoat()) //Dès qu'un bateau n'est pas coulé, on retourne false
			{
				return false;
			}
			
		}
		
		return true;
		
	}
	
	/**
	 * Vérifie si toutes les zones sont touchées.
	 * 
	 * @return <code>true</code> si tous les zones sont touchées et <code>false</code> si non.
	 */
	public boolean boardFull() {
			
		for(int i = 0 ; i < this.haut ; i++) //Vérifie l'état de chaque zones du champ de bataille (s'il a été touché ou pas)
		{ 
			for(int j = 0 ; j < this.larg ; j++)
			{
				if(this.board[i][j].getO() == null) //Dès qu'une zone n'est pas encore touchée, on retourne false
				{
					return false;
				}
			}
		}
			
		return true;
			
	}
	
	/**
	 * Retourne le nombre de bateaux coulés du champ de bataille.
	 * 
	 * @return Le nombre de bateaux coulés.
	 */
	public int nbBoatSink() {
		
		int n = 0;
		
		for(Boat b : this.boatList ) //Vérifie l'état de chaque bateau du champ de bataille (s'il est coulé ou pas)
		{ 
			if(b.sinkBoat())
			{
				n++;
			}
			
		}
		
		return n;
	}
	
	/**
	 * Affiche un champ de bataille en mode console.
	 */
	@Override
	public String toString() {
		
		String str = " Champ de bataille du joueur " + this.player.toString() + "\n\n";
			
		for(int i = 0 ; i < this.haut ; i++)
		{
			for(int j = 0 ; j < this.larg ; j++)
			{
				str += this.board[i][j].toString();
			}
			
			str += "\n";
		}			
		return str;
	}
	
	//GETTERS ET SETTERS
	/**
	 * Permet d'accéder à la hauteur du champ de bataille.
	 * 
	 * @return La heuteur du champ de bataille.
	 */
	public int getHaut() {
		return this.haut;
	}
	
	/**
	 * Permet d'accéder à la largeur du champ de bataille.
	 * 
	 * @return La largeur du champ de bataille.
	 */
	public int getLarg() {
		return this.larg;
	}
	
	/**
	 * Permet d'accéder à l'ensemble des zones du champ de bataille.
	 * 
	 * @return L'ensembles des zones du champ de bataille.
	 */
	public Area[][] getBoard(){
		return this.board;
	}

	/**
	 * Permet d'accéder au joueur du champ de bataille.
	 * 
	 * @return Le joueur auquel appartient le champ de bataille.
	 */
	public Player getPlayer() {
		return this.player;
	}
	
	/**
	 * Permet d'accéder à la liste des bateaux(la flotte)s du champ de bataille.
	 * 
	 * @return La flotte du champ de bataille
	 */
	public ArrayList<Boat> getBoatList() {
		return this.boatList;
	}

	/**
	 * Permet de modifier le joueur propriétaire du champ de bataille.
	 * 
	 * @param player
	 * 		Le nouveau joueur propriétaire.
	 */
	public void setPlayer(Player player) {
		this.player = player;
	}
	
}

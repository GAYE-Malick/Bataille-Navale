package fr.smdz_navalWar.Controller;

import java.util.ArrayList;

/**
 * <b>AbstractListenableModel permet à un champ de bataille d'avoir une liste de vues "suiveuses" qu'il impactera par son changement d'état.</b>
 * 
 * <p>
 * Cette classe a pour attribut: 
 * <ul>
 * <li> Une ArrayList de ModelListener <b>followers</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link AbstractListenableModel#addModelListener(ModelListener)} </b> </li>
 * <li> Un void <b> {@link AbstractListenableModel#removeModelListener(ModelListener)} </b> </li>
 * <li> Un void <b> {@link AbstractListenableModel#fireChange()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see ModelListener
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public abstract class AbstractListenableModel {
	
	/**
	 * 
	 */
	ArrayList<ModelListener> followers;
	
	/**
	 * <b>Constructeur de la classe AbstractListenableModel</b>
	 */
	public AbstractListenableModel() {
		
		this.followers = new ArrayList<>();
		
	}
	
	/**
	 * Permet d'ajouter un nouveau "suiveur" à la liste.
	 * 
	 * @param listener
	 * 		La nouvelle vue suiveuse.
	 */
	public void addModelListener(ModelListener listener) {
		this.followers.add(listener);
	}
	
	/**
	 * Permet de retirer un "suiveur" de la liste.
	 * 
	 * @param listener
	 * 		La vue suiveuse à retirer.
	 */
	public void removeModelListener(ModelListener listener) {
		this.followers.remove(listener);
	}
	
	/**
	 * Permet de prévenir les suiveurs du chagement du champ de bataille.<br>
	 * Met à jour tous les suiveurs.
	 */
	public void fireChange() {
		
		for(ModelListener a : this.followers) {
			a.modelUpdated(this);
		}		
	}

}

package fr.smdz_navalWar.Controller;

import fr.smdz_navalWar.View.SeaFrame;
import fr.smdz_navalWar.View.SeaView;

/**
 * <b>ModelListener est l'interface stockant les différentes méthodes requises à une vue "suiveuse" de champ de bataille.</b>
 * 
 * <p>
 * Elle stocke la méthode suivante: 
 * <ul>
 * <li> Un void <b> {@link ModelListener#modelUpdated(Object)} </b> </li>
 * </ul>
 * </p>
 * 
 * @see SeaFrame
 * @see SeaView
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public interface ModelListener {
	
	/**
	 * Met à jour la vue.
	 * 
	 * @param source
	 */
	public void modelUpdated(Object source);

}

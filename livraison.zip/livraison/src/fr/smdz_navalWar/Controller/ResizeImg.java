package fr.smdz_navalWar.Controller;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * <b>ResizeImg permet de redimensionner une image.</b>
 * 
 * <p>
 * Elle a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link ResizeImg#changeSize(String, String, int, int)} </b> </li>
 * <li> Un String <b> {@link ResizeImg#resizedImg(String, String, int, int)} </b> </li>
 * </ul>
 * 
 * </p>
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class ResizeImg {
	
	/**
	 * Permet de redimensionner une image.
	 * 
	 * @param inImg
	 * 		Le chemin(source) vers l'image d'origine.
	 * @param outImg
	 * 		Le chemin(source) vers la nouvelle image crée à partir de l'originale.
	 * @exception IOException Déclanchée si l'on entre de mauvais chemins d'accession.
	 * @return
	 * 		Le chemin(source) vers la nouvelle image sauvegardée.
	 * 
	 * @see ResizeImg#changeSize(String, String, int, int)
	 * 
	 */
	public static String resizedImg(String inImg, String outImg, int w, int h) {
		
		try 
        {
            int width = w;
            int height = h;
            ResizeImg.changeSize(inImg, outImg, width, height);
        }
        catch (IOException ex) 
        {
            ex.printStackTrace();
        }
		
		return outImg;
	}

	/**
	 * Permet de changer les dimension d'une image.<br>
	 * Elle sauvegarde, à partir de la première, une nouvelle image avec les dimension voulues.
	 * 
	 * @param inImg
	 * 		Le chemin(source) vers l'image d'origine.
	 * @param outImg
	 * 		Le chemin(source) vers la nouvelle image crée à partir de l'originale.
	 * @param w
	 * 		La largeur voulue de l'image.
	 * @param h
	 * 		La hauteur voulue de l'image.
	 * @throws IOException Déclanchée si l'on entre de mauvais chemins d'accession.
	 */
	 public static void changeSize(String inImg, String outImg, int w, int h) throws IOException {
			      
		 //Lecture de l'image d'entrée
		 File f = new File(inImg);
		 BufferedImage inputImage = ImageIO.read(f);
			 
		 //Création de l'image de sortie
		 BufferedImage img = new BufferedImage(w, h, inputImage.getType());
			 
		 //Passage de l'image d'entrée à l'image de sortie
		 Graphics2D g = img.createGraphics();
		 g.drawImage(inputImage, 0, 0, w, h, null);
		 g.dispose();

		 //Extraction de l'extension du fichier de sortie
		 String name = outImg.substring(outImg.lastIndexOf(".") + 1);
		 
		 //Ecriture dans le fichier de sortie
		 ImageIO.write(img, name, new File(outImg));
	 }
}

package fr.smdz_navalWar.Controller;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import fr.smdz_navalWar.Model.Obus;
import fr.smdz_navalWar.View.AreaPanel;

/**
 * <b>AreaListener permet de suivre le changement d'état d'une zone.</b>
 * 
 * <p>
 * Cette classe a pour attribut: 
 * <ul>
 * <li> Un AreaPanel <b>aP</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode: 
 * <ul>
 * <li> Un void <b> {@link AreaListener#mouseClicked(MouseEvent)} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see AreaPanel
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 * 
 */
public class AreaListener extends MouseAdapter {
	
	/**
	 * La zone en mode graphique.
	 */
	private AreaPanel aP;
	
	/**
	 * <b>Constructeur de la classe AreaListener</b>
	 * 
	 * @param aP
	 * 		La zone en mode graphique.
	 */
	public AreaListener(AreaPanel aP) {
		
		this.aP = aP;
	}
	
	/**
	 * Permet d'attaquer une zone et de mettre à jour la zone en mode graphique lors du clic sur la zone.
	 * 
	 * @param event
	 * 		L'action de cliquer sur une zone.
	 */
	public void mouseClicked(MouseEvent event) {
		
		if( this.aP.getA().getO() == null)
		{
			this.aP.getA().assault(new Obus());
			
			synchronized(this.aP.getA().getChB()){
				this.aP.getA().getChB().notify();
			}
		}
		this.aP.repaint();
	}

}

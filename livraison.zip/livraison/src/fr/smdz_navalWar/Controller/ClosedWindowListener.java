package fr.smdz_navalWar.Controller;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JOptionPane;

import fr.smdz_navalWar.View.SeaFrame;

/**
 * <b>ClosedWindowListener permet de suivre le changement d'état d'une zone.</b>
 * 
 * <p>
 * Cette classe a pour attribut: 
 * <ul>
 * <li> Un SeaFrame <b>base</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode: 
 * <ul>
 * <li> Un void <b> {@link ClosedWindowListener#windowClosing(WindowEvent)} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see SeaFrame
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class ClosedWindowListener extends WindowAdapter{
	
	/**
	 * La fenêtre principale du jeu.
	 */
	private SeaFrame base;
	
	/**
	 * <b>Constructeur de la classe ClosedWindowListener</b>
	 * 
	 * @param base
	 * 		La fenêtre principale du jeu.
	 */
	public ClosedWindowListener(SeaFrame base) {
		this.base = base;
	}

	/**
	 * Affiche une boîte de dialogue demandant la confirmation de la fermeture de la fenêtre principale.
	 * 
	 * @param e
	 * 		L'action de fermer la fenêtre.
	 */
	@Override
    public void windowClosing(WindowEvent e) {
		
      if (JOptionPane.showConfirmDialog(this.base, "Désirez-vous quitter l'application ?") == JOptionPane.YES_OPTION) System.exit(0);      
    }

}

/**
 * <b>Package regroupant les classes de la vue.</b>
 * 
 * @see AreaPanel
 * @see BattlefieldPanel
 * @see SeaFrame
 * @see SeaView
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 */
package fr.smdz_navalWar.View;

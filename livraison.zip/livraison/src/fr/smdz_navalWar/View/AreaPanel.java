package fr.smdz_navalWar.View;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import fr.smdz_navalWar.Controller.AreaListener;
import fr.smdz_navalWar.Model.Area;
import fr.smdz_navalWar.Model.Battlefield;
import fr.smdz_navalWar.Model.HumanPlayer;
import fr.smdz_navalWar.Model.RandomPlayer;

/**
 * <b>AreaPanel permet de déssiner les zones et les bateaux composants le champ de bataille.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un Battlefield <b>chB</b> </li>
 * <li> Un Area <b>a</b> </li>
 * <li> Un BattlefieldPanel <b>chBP</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b> {@link AreaPanel#paintComponent(Graphics)} </b> </li>
 * <li> Un Area <b> {@link AreaPanel#getA()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see Battlefield
 * @see Area
 * @see AreaListener
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class AreaPanel extends JPanel { //implements MouseListener{
	
	/**
	 * Le champ de bataille dans lequel se trouve la zone a.
	 */
	Battlefield chB;
	
	/**
	 * La zone à déssiner.
	 */
	Area a;
	
	/**
	 * Représente le panel du champ de bataille sur lequel se trouve la zone. 
	 */
	BattlefieldPanel chBP;
	
	/**
	 * <b>Constructeur de la classe AreaPanel</b>
	 * 
	 * @param a
	 * 		L'élément Area à passer à l'attribut a de la classe AreaPanel.
	 */
	public AreaPanel(Area a, BattlefieldPanel chBP) {
		
		super();
		this.chB = a.getChB();
		this.a = a;
		this.chBP = chBP;
		
		this.setBorder( BorderFactory.createLineBorder(Color.DARK_GRAY) );
		this.repaint();
		this.chBP.repaint();
		
		AreaListener aL = new AreaListener(this);
		
		if(this.chB.getPlayer() instanceof RandomPlayer)
			this.addMouseListener(aL);		
	}
	
	/**
	 * Permet de déssiner une zone et un bateau.
	 * 
	 * @param g
	 * 		Représente le pinceau utilisé pour déssiner.
	 */
	@Override
	public void paintComponent(Graphics g) {
		
		if(this.a.getChB().getPlayer() instanceof HumanPlayer)
		{
			if(this.a.getB() != null)
			{
				//paint en gris si la zone du joueur humain contient un bateau
				Color cl = new Color(169,172,177);
				g.setColor(cl);
				g.drawOval(this.getWidth()/2 - 15, this.getHeight()/2 - 15, 30, 30);
				g.setColor(cl);
				g.fillOval(this.getWidth()/2 -15, this.getHeight()/2 - 15, 30, 30);
			}
		}
		
		//Gère l'affichage lors du clic sur une zone
		if(this.a.getTouche())
		{
			if(this.a.getB() == null)
			{
				//paint en vert si la zone est ne contient pas de bateau
				g.setColor(Color.GREEN);
				g.drawOval(this.getWidth()/2 - 15, this.getHeight()/2 - 15, 30, 30);
				g.setColor(Color.GREEN);
				g.fillOval(this.getWidth()/2 -15, this.getHeight()/2 - 15, 30, 30);
			}
			
			else
			{
				//paint en orange si la zone contient un bateau qui n'est pas encore coulé
				g.setColor(Color.ORANGE);
				g.drawOval(this.getWidth()/2 - 15, this.getHeight()/2 - 15, 30, 30);
				g.setColor(Color.ORANGE);
				g.fillOval(this.getWidth()/2 -15, this.getHeight()/2 - 15, 30, 30);
				
				if( this.a.getB().sinkBoat() ) 
				{
					//paint en rouge si la zone contient un bateau qui est coulé
					g.setColor(Color.RED);
					g.drawOval(this.getWidth()/2 - 15, this.getHeight()/2 - 15, 30, 30);
					g.setColor(Color.RED);
					g.fillOval(this.getWidth()/2 -15, this.getHeight()/2 - 15, 30, 30);
					this.chBP.repaint();
					
				}
			}
		}
	}

	/**
	 * Méthode permettant d'avoir accès à la zone que la classe déssine.
	 * 
	 * @return La zone de référence(La valeur de l'attribut a de la classe).
	 */
	public Area getA() {
		return this.a;
	}

}

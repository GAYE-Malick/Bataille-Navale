package fr.smdz_navalWar.View;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

import fr.smdz_navalWar.Controller.ClosedWindowListener;
import fr.smdz_navalWar.Model.Battlefield;

/**
 * <b>SeaFrame est la fenêtre représentant la mer de jeu.</b>
 * <p>
 * Elle est la vue graphique du déroulement d'un jeu.<br>
 * 
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un Battlefield <b>chBmodel1</b> </li>
 * <li> Un Battlefield <b>chBmodel2</b> </li>
 * <li> Un JPanel <b>headHalf</b> </li>
 * </ul>
 *  
 *  Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un Battlefield <b> {@link SeaFrame#getChBmodel1()} </b> </li>
 * <li> Un Battlefield <b> {@link SeaFrame#getChBmodel2()} </b> </li> 
 * <li> Un JLabel <b> {@link SeaFrame#getHeadHalf()} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see Battlefield
 * @see BattlefieldPanel
 * @see ClosedWindowListener
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class SeaFrame extends JFrame {

	/**
	 * La référence sur le premier champ de bataille de la mer.
	 */
	private Battlefield chBmodel1;
	
	/**
	 * La référence sur le deuxième champ de bataille de la mer.
	 */
	private Battlefield chBmodel2;
	
	/**
	 * Affiche le nombre de bateaux coulés des joueurs.
	 */
	private JLabel headHalf;
	
	/**
	 * <b>Constructeur de la classe SeaFrame</b>
	 * 
	 * @param chB1
	 * 		Le premier champ de bataille de la mer.
	 * @param chB2
	 * 		Le deuxième champ de bataille de la mer.
	 */
	public SeaFrame(Battlefield chB1, Battlefield chB2) { //Comment matérialiser le fait d'avoir fini le jeu ?
		
		super("SMDZ-Jeu de Bataille Navale");
		
		// TODO L'icône et les paramètres de la fenêtre
		Image logo = Toolkit.getDefaultToolkit().getImage("src/images/navalWar_logo1.png");
		this.setIconImage(logo);
		this.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);		
		
		this.chBmodel1 = chB1;
		this.chBmodel2 = chB2;
		
		//Le contenu				
		Container cp = this.getContentPane();
		cp.setLayout(new BorderLayout());
		
		//Le panel gérant l'affichage des champs de bataille et le déroulement du jeu
		JPanel rightSide = new JPanel();
		rightSide.setLayout(new BorderLayout());
		
		JLabel gameRules = new JLabel();
		gameRules.setText( "<html> <h4> Chacun des deux joueurs dispose d’une flotte (ensemble de navires) positionnée sur une <br>"
				+ "grille (représentant une portion de mer en 2 dimensions). Les joueurs tirent chacun à leur <br>"
				+ "tour sur une position du camp adverse. Si un bateau adverse est impacté, le tir apparaît <br>"
				+ "d’une façon spécifique (rouge dans l’illustration) par rapport à un tir raté (vert dans <br>"
				+ "l’illustration). Le gagnant est le premier joueur parvenant à couler l’ensemble de la flotte adverse. </h4> </html>" );
		
		
		this.headHalf = new JLabel();
		headHalf.setText("<html> <h3>Joueur 1: " + this.chBmodel1.nbBoatSink() + " bateau(x) coulé(s) <br>Joueur 2: " + this.chBmodel2.nbBoatSink() + " bateau(x) coulé(s) </h3></html>");
		
		headHalf.setBorder(BorderFactory.createTitledBorder("<html> <h3> Statistiques </h3> </html>"));
		
		JPanel head = new JPanel(); //Gère l'affichage du texte placé au dessus.
		head.setLayout(new GridLayout(1,2));
		head.add(gameRules); //new JLabel(gameRules.getText()));
		head.add(headHalf);
		head.setBorder(null);
		
		rightSide.add(head, BorderLayout.NORTH);
		
		//Ajout des champs de bataille à l'interface graphique -- Vues
		BattlefieldPanel chB1Panel = new BattlefieldPanel(this.chBmodel1);
		BattlefieldPanel chB2Panel = new BattlefieldPanel(this.chBmodel2);
		
		JPanel middle = new JPanel();
		middle.setLayout(new BoxLayout(middle, BoxLayout.LINE_AXIS));
		middle.add(chB1Panel);
		middle.add(Box.createHorizontalStrut(20));
		middle.add(new JSeparator(SwingConstants.VERTICAL));
		middle.add(Box.createHorizontalStrut(10));
		middle.add(new JSeparator(SwingConstants.VERTICAL));
		middle.add(Box.createHorizontalStrut(20));
		middle.add(chB2Panel);
		
		rightSide.add(middle, BorderLayout.CENTER);
		
	//Le panel regroupant le panel de gauche et celui de droite
		
		JPanel base = new JPanel(); //Constitue l'élément au centre du contentPane
		base.setLayout(new BorderLayout());
		base.add(rightSide);
		
		base.setBorder(BorderFactory.createTitledBorder("<html> <h3> Mer </h3> </html>"));
		
		cp.add(base, BorderLayout.CENTER);
		
		//Fermerture de la fenêtre
		ClosedWindowListener cwl = new ClosedWindowListener(this);
		this.addWindowListener(cwl);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.pack();
	}

	//GETTERS ET SETTERS
	/**
	 * Permet d'accéder au champ de bataille du joueur 1
	 * 
	 * @return Le champ de bataille du joueur 1
	 */
	public Battlefield getChBmodel1() {
		return this.chBmodel1;
	}

	/**
	 * Permet d'accéder au champ de bataille du joueur 2
	 * 
	 * @return Le champ de bataille du joueur 2
	 */
	public Battlefield getChBmodel2() {
		return this.chBmodel2;
	}

	/**
	 * Permet d'accéder au JLabel affichant le nombre de bateaux coulés de chaque joueur.
	 * 
	 * @return Le JLabel affichant le nombre de bateaux coulés de chaque joueur.
	 */
	public JLabel getHeadHalf() {
		return this.headHalf;
	}
}

package fr.smdz_navalWar.View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import fr.smdz_navalWar.Controller.AreaListener;
import fr.smdz_navalWar.Controller.ModelListener;
import fr.smdz_navalWar.Model.Area;
import fr.smdz_navalWar.Model.Battlefield;

/**
 * <b>BattlefieldPanel permet de représenter un champ de bataille en mode graphique.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un Battlefield <b>chBmodel</b> </li>
 * <li> Un tableau d'AreaPanel <b>listAP</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un AreaPanel[] <b> {@link BattlefieldPanel#getListAP()} </b> </li>
 * <li> Un void <b> {@link BattlefieldPanel#paintArea(Graphics)} </b> </li> 
 * <li> Un void <b> {@link BattlefieldPanel#paintComponent(Graphics)} </b> </li>
 * <li> Un void <b> {@link BattlefieldPanel#modelUpdated(Object)} </b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see Battlefield
 * @see Area
 * @see AreaListener
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class BattlefieldPanel extends JPanel implements ModelListener{
	
	/**
	 * Le champ de bataille à représenter.
	 */
	Battlefield chBmodel;
	
	/**
	 * L'ensemble des AreaPanel constituants le champ de bataille graphique.
	 */
	AreaPanel[][] listAP;
	
	/**
	 * <b>Constructeur de la classe BattlefieldPanel</b>
	 * 
	 * @param chB
	 * 		Le champ de bataille à représenter.
	 */
	public BattlefieldPanel(Battlefield chB) {
		
		super();
		this.chBmodel = chB;
		this.chBmodel.addModelListener(this);
		
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		
		//La panel de base gère l'affichage au center
		JPanel base = new JPanel();
		base.setLayout(new BorderLayout());
		
		JPanel nord = new JPanel(); //Utilisé pour l'affichage des nombres du haut
		nord.setLayout(new GridLayout(1, this.chBmodel.getLarg()));
		for(int i = 0 ; i < this.chBmodel.getLarg() ; i++) {
			
			JLabel lab=new JLabel("<html> <b> " + i + " </b> </html>");
			lab.setHorizontalAlignment(SwingConstants.CENTER);
			nord.add(lab);
		}
		
		JPanel ouest = new JPanel(); //Utilisé pour l'affichage des nombres de gauche
		ouest.setLayout(new GridLayout(this.chBmodel.getHaut(), 1));
		for(int i = 0 ; i < this.chBmodel.getHaut() ; i++) {
			
			JLabel lab=new JLabel("<html> <b> " + i + " </b> </html>");
			lab.setHorizontalAlignment(SwingConstants.CENTER);
			ouest.add(lab);
		}
		
		JPanel middle = new JPanel();
		//middle.setSize( new Dimension((50*this.chBmodel.getLarg()) , (50*this.chBmodel.getHaut())) );
		middle.setLayout(new GridLayout(this.chBmodel.getHaut(), this.chBmodel.getLarg()));
		
		this.listAP = new AreaPanel[this.chBmodel.getHaut()][this.chBmodel.getLarg()];
		
		for(int i = 0 ; i < this.chBmodel.getHaut() ; i++)
		{
			for(int j = 0 ; j < this.chBmodel.getLarg() ; j++) 
			{
				AreaPanel ap = new AreaPanel(this.chBmodel.getBoard()[i][j], this);
				this.listAP[i][j] = ap;
				middle.add(ap);
			}
		}
		
		middle.setBackground(Color.WHITE);
		middle.setBorder( BorderFactory.createLineBorder(Color.BLACK) );
		
		base.add(nord, BorderLayout.NORTH);
		base.add(ouest, BorderLayout.WEST);
		base.add(middle, BorderLayout.CENTER);
		base.setBackground(Color.WHITE);
		
		//Le panel bas gère l'affichage au north
		JPanel bas = new JPanel();
		JLabel test = new JLabel("<html> <h3> Champ de bataille appartenant à: <br/>" + this.chBmodel.getPlayer().toString() + " </h3> </html>");
		test.setHorizontalAlignment(SwingConstants.CENTER);
		bas.add(test);
		
		this.add(Box.createRigidArea(new Dimension(10,10)));
		this.add(base);
		this.add(Box.createVerticalStrut(20) );
		this.add(bas);
		
		this.repaint();
	}
	
	/**
	 * Permet d'accéder à l'ensemble des AreaPanel constituants le champ de bataille graphique.
	 * 
	 * @return Les AreaPanel du champ de bataille.
	 */
	public AreaPanel[][] getListAP() {
		return this.listAP;
	}
	
    /**
     * Permet de déssiner chaque zone d'un champ de bataille.
     * 
     * @param g
     * 		Le pinceau de déssin.
     */
	public void paintArea(Graphics g) {
	
		for (int i = 0; i < this.chBmodel.getHaut() ; i++) {
			for (int j = 0; j < this.chBmodel.getLarg() ; j++) {
	            
				this.listAP[i][j].repaint();
	        }
	    }
	}

	/**
	 * Affiche le champ de bataille.
	 */
	@Override
	public void paintComponent(Graphics g) {

	    this.paintArea(g);
	}
	
	/**
	 * Met à jour la vue du champ de bataille
	 */
	@Override
	public void modelUpdated(Object source) {
		this.repaint();
        this.revalidate();
	}
	
}

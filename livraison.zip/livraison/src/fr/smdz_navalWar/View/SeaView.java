package fr.smdz_navalWar.View;

import fr.smdz_navalWar.Controller.ModelListener;
import fr.smdz_navalWar.Model.Battlefield;

/**
 * <b>SeaView est la classe qui permet d'afficher une mer munie de ses 2 champs de bataille en mode console.</b>
 * 
 * <p>
 * Cette classe a pour attribut(s): 
 * <ul>
 * <li> Un Battlefield <b>model1</b> </li>
 * <li> Un Battlefield <b>model2</b> </li>
 * <li> Un String <b>name</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthode(s): 
 * <ul>
 * <li> Un void <b>modelUpdated</b> </li>
 * </ul>
 * 
 * Veuillez noter que le constructeur n'est pas cité.
 * </p>
 * 
 * @see Battlefield
 * 
 * @author Steven Martin, Malick Sarr Gaye, Mame Waly Bamba Diouf, Ahouefa Zounon
 * @version 1.0
 *
 */
public class SeaView implements ModelListener{
	
	/**
	 * La référence sur le premier champ de bataille de la mer.
	 */
	Battlefield model1;
	
	/**
	 * La référence sur le deuxième champ de bataille de la mer.
	 */
	Battlefield model2;
	
	/**
	 * La référence sur le nom de la mer.
	 */
	String name;
	
	/**
	 * <b>Constructeur de la classe SeaView</b>
	 * 
	 * @param name
	 * 		Le nom de la mer.
	 * @param chB1
	 * 		Le premier champ de bataille de la mer.
	 * @param chB2
	 * 		Le deuxième champ de bataille de la mer.
	 */
	public SeaView(String name, Battlefield chB1, Battlefield chB2) {
		
		this.name = name;
		this.model1 = chB1;		
		this.model2 = chB2;
		
		this.model1.addModelListener(this);
		this.model2.addModelListener(this);
		
	}

	/**
	 * Permet la mise à jour de l'affichage d'une mer dès le changement d'un champ de bataille.
	 */
	@Override
	public void modelUpdated(Object source) {
		
		System.out.println(this.name + " : \n\n" + this.model1.toString() + "\n" + this.model2.toString());
	}

}
